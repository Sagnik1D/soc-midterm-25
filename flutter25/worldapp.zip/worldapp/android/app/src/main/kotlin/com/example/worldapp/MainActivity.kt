package com.example.worldapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
